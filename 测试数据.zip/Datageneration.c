#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define GROUP_COUNT 1000
#define MAX_WORD_LENGTH 20

// �������С�� 20 ���ַ���Ӣ�ĵ���
void generate_random_word(char* word) {
    int length = rand() % 19 + 1;
    for (int i = 0; i < length; i++) {
        word[i] = 'a' + rand() % 26;
    }
    word[length] = '\0';
}

// ���� 11 λ�ֻ���
void generate_phone_number(char* phone) {
    phone[0] = '1';
    for (int i = 1; i < 11; i++) {
        phone[i] = '0' + rand() % 10;
    }
    phone[11] = '\0';
}

// �����������
void generate_password(char* password) {
    int length = rand() % 15 + 1;
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + rand() % 26;
    }
    password[length] = '\0';
}

// �����û�ע������
void generate_user_registration_data(char phones[GROUP_COUNT][20]) {
    FILE* fp = fopen("user_registration.txt", "wt");
    if (fp == NULL) {
        perror("Failed to open file");
        return;
    }

    for (int i = 0; i < GROUP_COUNT; i++) {
        char name[30];
        char mima[20];
        int userType = rand() % 5;

        generate_phone_number(phones[i]);
        generate_random_word(name);
        generate_password(mima);

        fprintf(fp, "%s %s %s %d\n", phones[i], name, mima, userType);
    }

    fclose(fp);
}

// ���� read_from_file ��Ҫ������
void generate_read_from_file_data(char phones[GROUP_COUNT][20]) {
    FILE* fp = fopen("test.txt", "wt");
    if (fp == NULL) {
        perror("Failed to open file");
        return;
    }

    for (int i = 0; i < GROUP_COUNT; i++) {
        char goods_name[MAX_WORD_LENGTH];
        int goods_type = rand() % 5;
        float goods_weight = (float)(rand() % 1000) / 10.0; // 0 - 100.0
        float price = (float)(rand() % 10) + (float)(rand() % 100) / 100.0;

        generate_random_word(goods_name);

        fprintf(fp, "%s %d %.1f %.2f %s\n", goods_name, goods_type, goods_weight, price, phones[i]);
    }

    fclose(fp);
}

int main() {
    srand(time(NULL));

    char phones[GROUP_COUNT][20];

    generate_user_registration_data(phones);
    generate_read_from_file_data(phones);

    printf("Test data generated successfully.\n");

    return 0;
}