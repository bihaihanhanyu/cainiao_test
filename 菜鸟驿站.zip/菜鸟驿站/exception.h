#pragma once
#include"struct_def.h"
/*void trace_package(const char* target_id) {
    FILE* log_file = fopen("operation.log", "r");
    if (log_file == NULL) return;
    char line[256];
    while (fgets(line, sizeof(line), log_file)) {
        if (strstr(line, target_id) != NULL) {
            printf("%s", line); // ���ƥ�����־��
        }
    }
    fclose(log_file);
}
void log_exception(const PackageException* exception) {
    FILE* log_file = fopen("exception.log", "a"); // ׷��ģʽ
    if (log_file != NULL) {
        char time_str[20];
        format_time(exception->exception_time, time_str);

        //const
        char* type_str;
        switch (exception->type) {
        case LOST:
            type_str = "��ʧ";
            break;
        case DAMAGED:
            type_str = "��";
            break;
        case OVERDUE_STAY:
            type_str = "��������";
            break;
        case INFORMATION_ERROR:
            type_str = "��Ϣ����";
            break;
        default:
            type_str = "δ֪�쳣";
            break;
        }

        fprintf(log_file, "[%s] %s - ����:%s ����:%s\n",
            time_str, type_str, exception->package_id, exception->description);
        fclose(log_file);
    }
    return;
}
void query_package_exceptions(char package_id[20])
{
    FILE* log_file = fopen("exception.log", "r");
    if (log_file == NULL)
    {
        printf("�������쳣����\n");
        return;
    }
    char line[256];
    while (fgets(line, sizeof(line), log_file)) {
        if (strstr(line, package_id) != NULL) {
            {
                printf("%s", line); // ���ƥ�����־��
                fclose(log_file);
            }
        }
    }

        printf("�ö����������쳣���\n");
    fclose(log_file);
}
*/
void log_exception(const PackageException* exception) {
    FILE* log_file = fopen("exception.txt", "a");
    if (log_file == NULL) {
        perror("�޷�����־�ļ�");
        return;
    }

    char time_str[20];
    format_time(exception->exception_time, time_str);

    const char* type_str;
    switch (exception->type) {
    case LOST:
        type_str = "��ʧ";
        break;
    case DAMAGED:
        type_str = "��";
        break;
    case OVERDUE_STAY:
        type_str = "��������";
        break;
    case INFORMATION_ERROR:
        type_str = "��Ϣ����";
        break;
    default:
        type_str = "δ֪�쳣";
        break;
    }

    fprintf(log_file, "[%s] %s - ����:%s ����:%s\n",
        time_str, type_str, exception->package_id, exception->description);
    fclose(log_file);
    return;
}

void query_package_exceptions(char package_id[20]) {
    FILE* log_file = fopen("exception.txt", "r");
    if (log_file == NULL) {
        printf("�������쳣����\n");
        return;
    }

    char line[256];
    int found = 0;
    while (fgets(line, sizeof(line), log_file)) {
        if (strstr(line, package_id) != NULL) {
            printf("%s", line);
            found = 1;
        }
    }

    if (!found) {
        printf("�ö����������쳣���\n");
    }

    fclose(log_file);
}