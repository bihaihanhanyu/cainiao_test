#pragma once
#include"struct_def.h"

int load_config(SystemConfig* config) {
    FILE* fp = fopen("config.txt", "r");
    if (!fp) return 0; // �ļ������ڷ���0

    char line[256];
    while (fgets(line, sizeof(line), fp)) { // ���ж�ȡ
        // ����ע���кͿ���
        if (line[0] == '#' || line[0] == '\n') continue;

        // �ָ��ֵ��
        char* key = strtok(line, "=");
        char* value = strtok(NULL, "\n");

        // ������ͬ����
        if (strcmp(key, "admin_password") == 0) {
            strcpy(config->admin_password, value);
        }
        else if (strcmp(key, "capacity_threshold") == 0) {
            config->capacity_threshold = atoi(value); // �ַ���ת����
        }
        else if (strcmp(key, "staff_pass") == 0) {
            strcpy(config->staff_pass, value);
        }
    }
    fclose(fp);
    return 1;
}


void save_config(SystemConfig* config) {
    FILE* fp = fopen("config.txt", "w");
    if (!fp) return;

    fprintf(fp, "admin_password=%s\n", config->admin_password);
    fprintf(fp, "capacity_threshold=%d\n", config->capacity_threshold);
    fprintf(fp, "staff_pass=%s\n", config->staff_pass);
    fclose(fp);
}

void init_default_config() {
    SystemConfig default_config = {
       "admin12356",
         500,
         "1"
    };
    save_config(&default_config);
}

int log_operation(const char* operation, const char* package_id, const char* operator_id) {
    FILE* log_file = fopen("operation.log", "a"); // ׷��ģʽ
    if (log_file != NULL) {
        time_t now = get_current_timestamp();
        char time_str[20];
        format_time(now, time_str);

        fprintf(log_file, "[%s] %s - ����:%s ����Ա:%s\n",
            time_str, operation, package_id, operator_id);
        fclose(log_file);
        return 1; // �ɹ�д����־
    }
    return 0; // ���ļ�ʧ��
}